﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace  GetFileNamesRename
{
    public class CDebugLog
    {
        private static Mutex m_mutexLog = new Mutex();

        public void DebugLog(string text)
        {
            string filename;
            string data=string.Empty;

            ////if (! CMarkSystem.SystemSettings.EnablePrintLog)
            ////    return;

            m_mutexLog.WaitOne();

            filename = Application.StartupPath + "\\Temperature.txt";
            //data = System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss", System.Globalization.DateTimeFormatInfo.InvariantInfo);
            //data += " " + text + "\r\n";
            data += text + "\r\n";
            System.IO.File.AppendAllText(filename, data);

            m_mutexLog.ReleaseMutex();
        }

        public void AppendRecord(string text)
        {
            string filename;

            m_mutexLog.WaitOne();

            filename = Application.StartupPath + "\\log.txt";
            System.IO.File.AppendAllText(filename, text);

            m_mutexLog.ReleaseMutex();
        }
    }
}


//// debug log
//private void DebugLog()
//{
//    string[] strAry = new string[10];
//    float temper = 12.3456f;
//    for (int i = 0; i < strAry.Length; i++)
//    {
//        strAry[i] = i.ToString() + "    " + (i * temper).ToString();
//        Debug.DebugLog(strAry[i]);
//    }



//}